import { useState } from "react";
import { User, CheckCircle } from "lucide-react";
import type { SeatPassenger } from "../types";
import { SeatDetailCard } from "./SeatDetailCard";

export function CarSeatLayout({
  passengers,
  onSeatClick,
  selectedSeat,
  newlyBookedSeats,
  totalSeats = 4,
}: {
  passengers: SeatPassenger[];
  onSeatClick: (seatNum: number) => void;
  selectedSeat: number | null;
  newlyBookedSeats?: number[];
  totalSeats?: number;
}) {
  const getSeatData = (n: number) => passengers.find(p => p.seatNumber === n);

  const statusColor = (p?: SeatPassenger) => {
    if (!p) return { bg: "bg-zinc-100 dark:bg-zinc-800", border: "border-zinc-200 dark:border-zinc-700", text: "text-zinc-400 dark:text-zinc-500" };
    if (p.status === "dropped_off") return { bg: "bg-zinc-200 dark:bg-zinc-700", border: "border-zinc-300 dark:border-zinc-600", text: "text-zinc-500 dark:text-zinc-400" };
    if (p.status === "picked_up") return { bg: "bg-emerald-500 dark:bg-emerald-600", border: "border-emerald-400 dark:border-emerald-500", text: "text-white" };
    return { bg: "bg-amber-400 dark:bg-amber-500", border: "border-amber-300 dark:border-amber-400", text: "text-amber-900 dark:text-amber-100" };
  };

  const truncName = (name: string) => {
    const first = (name || "").split(" ")[0];
    return first.length > 8 ? first.slice(0, 8) + "…" : first;
  };

  const statusLabel = (p?: SeatPassenger) => {
    if (!p) return "";
    if (p.status === "dropped_off") return "Высажен";
    if (p.status === "picked_up") return "В машине";
    return "Ожидает";
  };

  const renderSeat = (n: number) => {
    const p = getSeatData(n);
    const filled = !!p;
    const isSelected = selectedSeat === n;
    const isNewlyBooked = newlyBookedSeats?.includes(n) ?? false;
    const colors = statusColor(p);

    return (
      <button
        key={n}
        onClick={() => onSeatClick(n)}
        className={`flex-1 min-w-0 flex flex-col items-center gap-1 py-2 rounded-xl transition-all active:scale-95 ${isNewlyBooked ? "seat-booking-anim" : ""} ${
          isSelected ? "bg-zinc-100 dark:bg-zinc-800 shadow-inner" : ""
        }`}
      >
        <div className={`relative w-14 h-14 rounded-2xl ${colors.bg} border-2 ${colors.border} flex items-center justify-center transition-all ${
          isSelected ? "scale-105 shadow-lg ring-2 ring-zinc-900/20" : ""
        }`}>
          {filled ? (
            <svg width="28" height="28" viewBox="0 0 40 40" fill="none">
              <circle cx="20" cy="14" r="6" fill="currentColor" className={colors.text} opacity="0.9" />
              <path d="M9 34C9 27 13 23 20 23C27 23 31 27 31 34" fill="currentColor" className={colors.text} opacity="0.7" />
            </svg>
          ) : (
            <span className="text-xl font-bold text-zinc-300">{n}</span>
          )}
          {filled && p.status === "picked_up" && (
            <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center">
              <CheckCircle className="w-3.5 h-3.5 text-white" />
            </div>
          )}
          {filled && p.status === "dropped_off" && (
            <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-zinc-400 dark:bg-zinc-500 flex items-center justify-center">
              <CheckCircle className="w-3.5 h-3.5 text-white" />
            </div>
          )}
        </div>
        <span className={`text-xs font-bold leading-tight truncate max-w-[70px] ${filled ? "text-foreground" : "text-muted-foreground"}`}>
          {filled ? truncName(p.name) : `Место ${n}`}
        </span>
        {filled && (
          <span className={`text-[12px] font-bold leading-none ${
            p.status === "picked_up" ? "text-emerald-600 dark:text-emerald-400" : p.status === "dropped_off" ? "text-zinc-400 dark:text-zinc-500" : "text-amber-600 dark:text-amber-400"
          }`}>
            {statusLabel(p)}
          </span>
        )}
        {!filled && <span className="text-[12px] text-muted-foreground/60">Свободно</span>}
      </button>
    );
  };

  const allSeats = Array.from({ length: totalSeats }, (_, i) => i + 1);

  return (
    <div className="relative">
      <div className="bg-card rounded-2xl border border-border overflow-hidden px-2 py-3">
        <div className="flex items-center gap-0.5">
          <div className="flex flex-col items-center shrink-0">
            <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Перед</p>
            {renderSeat(1)}
          </div>

          {totalSeats > 1 && (
            <>
              <div className="w-px self-stretch bg-border mx-0.5 shrink-0" />
              <div className="flex flex-col items-center flex-1 min-w-0">
                <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-wider mb-1">
                  {totalSeats === 2 ? "Зад" : "Задний ряд"}
                </p>
                <div className="flex items-center gap-0.5 w-full">
                  {allSeats.slice(1).map(n => renderSeat(n))}
                </div>
              </div>
            </>
          )}
        </div>

        <div className="mt-2.5 pt-2 border-t border-border flex items-center justify-center gap-5 text-[9px] font-bold text-muted-foreground uppercase tracking-wider">
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-400 dark:bg-amber-500" />Ожидает</span>
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />В машине</span>
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-zinc-300 dark:bg-zinc-600" />Высажен</span>
        </div>
      </div>
    </div>
  );
}

