import { useState, useCallback, useRef, useTransition } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useConnection } from "@/hooks/use-connection";
import { enqueueAction } from "@/lib/offline-queue";
import { getCached, setCached } from "@/lib/api-cache";
import type { DriverScreen, Ride, SeatPassenger, TripStop, CityInfo, PickupRouteData } from "../types";
import { BASE_URL } from "../constants";

interface ActionRefs {
  activeRideRef: React.MutableRefObject<Ride | null>;
  isOnlineRef: React.MutableRefObject<boolean>;
  isProcessingRef: React.MutableRefObject<boolean>;
  pendingResyncRef: React.MutableRefObject<boolean>;
  completedAtRef: React.MutableRefObject<number>;
  stateVersionRef: React.MutableRefObject<number>;
  headersRef: React.MutableRefObject<Record<string, string>>;
  abortRef: React.MutableRefObject<AbortController | null>;
  routeRebuildTimer: React.MutableRefObject<ReturnType<typeof setTimeout> | null>;
  activePassengersRef: React.MutableRefObject<SeatPassenger[]>;
  fullResyncRef: React.MutableRefObject<() => Promise<void>>;
}

interface ActionSetters {
  setScreen: React.Dispatch<React.SetStateAction<DriverScreen>>;
  setActiveRide: React.Dispatch<React.SetStateAction<Ride | null>>;
  setActivePassengers: React.Dispatch<React.SetStateAction<SeatPassenger[]>>;
  setTripStops: React.Dispatch<React.SetStateAction<TripStop[]>>;
  setPickupRoute: React.Dispatch<React.SetStateAction<PickupRouteData | null>>;
  setCompletedRide: React.Dispatch<React.SetStateAction<Ride | null>>;
  setLoading: React.Dispatch<React.SetStateAction<boolean>>;
}

export function useOrderActions(refs: ActionRefs, setters: ActionSetters) {
  const { token, user, refreshUser } = useAuth();
  const { toast } = useToast();
  const connection = useConnection();

  const [actionLoading, setActionLoading] = useState(false);
  const [passengerActionLoading, setPassengerActionLoading] = useState<number | null>(null);
  const [isCompleting, setIsCompleting] = useState(false);
  const [clientActionLoading, setClientActionLoading] = useState(false);
  const [marketListings, setMarketListings] = useState<any[]>([]);
  const [, startListTransition] = useTransition();
  const [buyingId, setBuyingId] = useState<number | null>(null);
  const [cities, setCities] = useState<CityInfo[]>([]);
  const [availableRoutes, setAvailableRoutes] = useState<{ fromCity: string; toCity: string }[]>([]);

  const isCompletingRef = useRef(false);
  isCompletingRef.current = isCompleting;

  const loadActiveRide = useCallback(async () => {
    if (!token) return;
    const cacheKey = `active_ride_${user?.id || ""}`;
    const cachedRide = getCached<any>(cacheKey);
    if (cachedRide?.ride) {
      setters.setActiveRide(cachedRide.ride);
      setters.setActivePassengers(cachedRide.passengers || []);
    }
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/my-active-ride`, { headers: refs.headersRef.current });
      if (!res.ok) return;
      const data = await res.json();
      const serverVersion = data.version || 0;
      if (data.ride && serverVersion > 0 && serverVersion < refs.stateVersionRef.current) return;
      refs.stateVersionRef.current = serverVersion;
      if (data.ride) {
        setCached(cacheKey, data, 10 * 60 * 1000);
        setters.setActiveRide(data.ride);
        setters.setActivePassengers(data.passengers || []);
        if (data.ride.status === "in_progress") setters.setScreen(prev => prev !== "active" ? "active" : prev);
        else if (data.ride.status === "accepted") setters.setScreen(prev => (prev === "idle" || prev === "route_select" || prev === ("loading" as any)) ? "seat_view" : prev);
      } else {
        setCached(cacheKey, null, 1000);
        setters.setScreen(prev => {
          if (prev === "seat_view" || prev === "active" || prev === "pickup" || prev === ("loading" as any)) {
            refs.stateVersionRef.current = 0;
            setters.setActiveRide(null);
            setters.setActivePassengers([]);
            setters.setPickupRoute(null);
            setters.setTripStops([]);
            return refs.isOnlineRef.current ? "route_select" : "idle";
          }
          return prev;
        });
      }
    } catch {}
    setters.setLoading(false);
  }, [token]);

  const loadMarketListings = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch(`${BASE_URL}/api/marketplace/listings`, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        const newListings = data.listings || [];
        startListTransition(() => {
          setMarketListings(prev => JSON.stringify(prev) === JSON.stringify(newListings) ? prev : newListings);
        });
      }
    } catch {}
  }, [token]);

  const handleBuyListing = async (listingId: number) => {
    if (buyingId) return;
    setBuyingId(listingId);
    try {
      const res = await fetch(`${BASE_URL}/api/marketplace/buy`, {
        method: "POST", headers: refs.headersRef.current, body: JSON.stringify({ listingId }),
      });
      const data = await res.json();
      if (res.ok) {
        toast({ title: "Заказ куплен!" });
        refreshUser();
        loadMarketListings();
        loadActiveRide();
      } else {
        toast({ variant: "destructive", title: data.message || "Ошибка покупки" });
      }
    } catch { toast({ variant: "destructive", title: "Ошибка сети" }); }
    setBuyingId(null);
  };

  const handleCreateRide = async (fromCity: string, toCity: string, departureTime: string) => {
    setActionLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/create-ride`, {
        method: "POST", headers: refs.headersRef.current, body: JSON.stringify({ fromCity, toCity, departureTime }),
      });
      const data = await res.json();
      if (res.ok) {
        toast({ title: "Рейс создан!" });
        setters.setActiveRide(data);
        setters.setActivePassengers([]);
        setters.setScreen("seat_view");
        refreshUser();
      } else {
        toast({ variant: "destructive", title: data.message || "Ошибка создания рейса" });
      }
    } catch { toast({ variant: "destructive", title: "Ошибка сети" }); }
    finally { setActionLoading(false); }
  };

  const handleStartRide = async (retry = false, actionId?: string) => {
    const ride = refs.activeRideRef.current;
    if (!ride || actionLoading) return;
    setActionLoading(true);
    const aid = actionId || crypto.randomUUID();
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/start`, {
        signal: AbortSignal.timeout(15000),
        method: "POST",
        headers: { ...refs.headersRef.current, "X-Action-Id": aid },
        body: JSON.stringify({ rideId: ride.id }),
      });
      const data = await res.json();
      if (res.ok) {
        if (data._replayed && typeof data._rideVersion === "number" && data._rideVersion < refs.stateVersionRef.current) {
          await refs.fullResyncRef.current(); return;
        }
        toast({ title: "Поездка начата!" });
        setters.setActiveRide({ ...ride, status: "in_progress" });
        setters.setScreen("active");
        refreshUser();
      } else if (data.error === "version_conflict" && !retry) {
        setActionLoading(false);
        await refs.fullResyncRef.current();
        await handleStartRide(true, crypto.randomUUID()); return;
      } else { toast({ variant: "destructive", title: data.message || "Ошибка" }); }
    } catch {
      if (!navigator.onLine) {
        enqueueAction({ type: "start", endpoint: `${BASE_URL}/api/drivers/start`, method: "POST",
          headers: { ...refs.headersRef.current, "X-Action-Id": aid },
          body: JSON.stringify({ rideId: ride.id }), rideId: ride.id, localLabel: "Начать поездку" });
        setters.setActiveRide({ ...ride, status: "in_progress" });
        setters.setScreen("active");
        toast({ title: "Поездка начата (офлайн) — синхронизируется при подключении" });
      } else { toast({ variant: "destructive", title: "Ошибка сети" }); }
    } finally { setActionLoading(false); }
  };

  const handleComplete = async () => {
    const ride = refs.activeRideRef.current;
    if (!ride || actionLoading || isCompleting || refs.isProcessingRef.current) return;
    const passengersSnapshot = [...refs.activePassengersRef.current];

    refs.isProcessingRef.current = true;
    refs.abortRef.current?.abort();
    refs.abortRef.current = new AbortController();
    if (refs.routeRebuildTimer.current) { clearTimeout(refs.routeRebuildTimer.current); refs.routeRebuildTimer.current = null; }

    setIsCompleting(true);
    setActionLoading(true);
    refs.stateVersionRef.current = 0;
    refs.completedAtRef.current = Date.now();
    setters.setActiveRide(null);
    setters.setActivePassengers([]);
    setters.setTripStops([]);
    setters.setPickupRoute(null);
    setters.setCompletedRide({ ...ride, seatPassengers: passengersSnapshot });
    setters.setScreen("completed");

    try {
      const res = await fetch(`${BASE_URL}/api/drivers/complete`, {
        method: "POST", headers: refs.headersRef.current, body: JSON.stringify({ rideId: ride.id }),
      });
      const data = await res.json();
      if (res.ok) { toast({ title: "Рейс завершён!" }); refreshUser(); }
      else {
        const errMsg = data.error === "no_driver" ? "Водитель не назначен" : data.error === "no_price" ? "Ошибка расчёта" : data.message || "Ошибка завершения";
        toast({ variant: "destructive", title: errMsg });
        setters.setActiveRide(ride);
        setters.setActivePassengers(passengersSnapshot);
        setters.setScreen("active");
        setters.setCompletedRide(null);
      }
    } catch {
      if (!navigator.onLine) {
        enqueueAction({ type: "complete", endpoint: `${BASE_URL}/api/drivers/complete`, method: "POST",
          headers: refs.headersRef.current, body: JSON.stringify({ rideId: ride.id }), rideId: ride.id, localLabel: "Завершить рейс" });
        toast({ title: "Рейс завершён (офлайн)" });
      } else {
        toast({ variant: "destructive", title: "Ошибка сети" });
        setters.setActiveRide(ride);
        setters.setActivePassengers(passengersSnapshot);
        setters.setScreen("active");
        setters.setCompletedRide(null);
      }
    } finally {
      refs.isProcessingRef.current = false;
      refs.pendingResyncRef.current = false;
      setActionLoading(false);
      setIsCompleting(false);
      refs.abortRef.current = null;
    }
  };

  const handleCancel = async (retry = false, actionId?: string) => {
    const ride = refs.activeRideRef.current;
    if (!ride || actionLoading || refs.isProcessingRef.current) return;
    if (!retry && !confirm("Отменить рейс? Штраф 10 000 сум")) return;
    refs.isProcessingRef.current = true;
    refs.abortRef.current?.abort();
    refs.abortRef.current = new AbortController();
    if (refs.routeRebuildTimer.current) { clearTimeout(refs.routeRebuildTimer.current); refs.routeRebuildTimer.current = null; }
    setActionLoading(true);
    const aid = actionId || crypto.randomUUID();
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/cancel`, {
        method: "POST", headers: { ...refs.headersRef.current, "X-Action-Id": aid },
        body: JSON.stringify({ rideId: ride.id }),
      });
      const data = await res.json();
      if (res.ok) {
        if (data._replayed && typeof data._rideVersion === "number" && data._rideVersion < refs.stateVersionRef.current) {
          await refs.fullResyncRef.current(); return;
        }
        toast({ title: "Рейс отменён" });
        refs.stateVersionRef.current = 0;
        setters.setActiveRide(null); setters.setActivePassengers([]); setters.setTripStops([]); setters.setPickupRoute(null);
        setters.setScreen(refs.isOnlineRef.current ? "route_select" : "idle");
        refreshUser();
      } else if (data.error === "version_conflict" && !retry) {
        refs.isProcessingRef.current = false; refs.pendingResyncRef.current = false; setActionLoading(false);
        await refs.fullResyncRef.current();
        await handleCancel(true, crypto.randomUUID()); return;
      } else { toast({ variant: "destructive", title: data.message || "Ошибка" }); }
    } catch (e: any) {
      if (e?.name === "AbortError") {}
      else if (!navigator.onLine) {
        enqueueAction({ type: "cancel", endpoint: `${BASE_URL}/api/drivers/cancel`, method: "POST",
          headers: { ...refs.headersRef.current, "X-Action-Id": aid },
          body: JSON.stringify({ rideId: ride.id }), rideId: ride.id, localLabel: "Отменить рейс" });
        refs.stateVersionRef.current = 0;
        setters.setActiveRide(null); setters.setActivePassengers([]); setters.setTripStops([]); setters.setPickupRoute(null);
        setters.setScreen("idle");
        toast({ title: "Рейс отменён (офлайн)" });
      } else { toast({ variant: "destructive", title: "Ошибка сети" }); }
    } finally {
      refs.isProcessingRef.current = false; refs.pendingResyncRef.current = false; setActionLoading(false);
    }
  };

  const handlePassengerPickup = async (passengerId: number, retry = false, actionId?: string) => {
    if (passengerActionLoading || refs.isProcessingRef.current) return;
    refs.isProcessingRef.current = true;
    setPassengerActionLoading(passengerId);
    refs.abortRef.current?.abort();
    refs.abortRef.current = new AbortController();
    const aid = actionId || crypto.randomUUID();
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/passenger/${passengerId}/pickup`, {
        method: "POST", headers: { ...refs.headersRef.current, "X-Action-Id": aid },
      });
      const data = await res.json();
      if (res.ok) {
        if (data._replayed && typeof data._rideVersion === "number" && data._rideVersion < refs.stateVersionRef.current) {
          await refs.fullResyncRef.current(); return;
        }
        toast({ title: data.message || "Пассажир подобран!" });
        setters.setActivePassengers(prev => prev.map(p => p.id === passengerId ? { ...p, status: "picked_up" } : p));
      } else if (data.error === "version_conflict" && !retry) {
        refs.isProcessingRef.current = false; refs.pendingResyncRef.current = false; setPassengerActionLoading(null);
        await refs.fullResyncRef.current();
        await handlePassengerPickup(passengerId, true, crypto.randomUUID()); return;
      } else { toast({ variant: "destructive", title: data.message || "Ошибка" }); }
    } catch (e: any) {
      if (e?.name === "AbortError") {}
      else if (!navigator.onLine) {
        enqueueAction({ type: "pickup", endpoint: `${BASE_URL}/api/drivers/passenger/${passengerId}/pickup`, method: "POST",
          headers: { ...refs.headersRef.current, "X-Action-Id": aid }, passengerId, rideId: refs.activeRideRef.current?.id, localLabel: "Забрать пассажира" });
        setters.setActivePassengers(prev => prev.map(p => p.id === passengerId ? { ...p, status: "picked_up" } : p));
        toast({ title: "Сохранено офлайн" });
      } else { toast({ variant: "destructive", title: "Ошибка сети" }); }
    } finally {
      refs.isProcessingRef.current = false; refs.pendingResyncRef.current = false; setPassengerActionLoading(null);
      if (refs.routeRebuildTimer.current) clearTimeout(refs.routeRebuildTimer.current);
      if (navigator.onLine) refs.routeRebuildTimer.current = setTimeout(() => refs.fullResyncRef.current(), 300);
    }
  };

  const handlePassengerDropoff = async (passengerId: number, retry = false, actionId?: string) => {
    if (passengerActionLoading || refs.isProcessingRef.current) return;
    refs.isProcessingRef.current = true;
    setPassengerActionLoading(passengerId);
    refs.abortRef.current?.abort();
    refs.abortRef.current = new AbortController();
    const aid = actionId || crypto.randomUUID();
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/passenger/${passengerId}/dropoff`, {
        method: "POST", headers: { ...refs.headersRef.current, "X-Action-Id": aid },
      });
      const data = await res.json();
      if (res.ok) {
        if (data._replayed && typeof data._rideVersion === "number" && data._rideVersion < refs.stateVersionRef.current) {
          await refs.fullResyncRef.current(); return;
        }
        toast({ title: data.message || "Пассажир высажен!" });
        setters.setActivePassengers(prev => prev.map(p => p.id === passengerId ? { ...p, status: "dropped_off" } : p));
        if (data.autoCompleted) {
          refs.completedAtRef.current = Date.now();
          setters.setCompletedRide({ ...refs.activeRideRef.current!, seatPassengers: [...refs.activePassengersRef.current] });
          setters.setScreen("completed");
          refs.stateVersionRef.current = 0;
          setters.setActiveRide(null); setters.setActivePassengers([]); setters.setTripStops([]); setters.setPickupRoute(null);
          refreshUser();
          refs.isProcessingRef.current = false; refs.pendingResyncRef.current = false; setPassengerActionLoading(null);
          return;
        }
      } else if (data.error === "version_conflict" && !retry) {
        refs.isProcessingRef.current = false; refs.pendingResyncRef.current = false; setPassengerActionLoading(null);
        await refs.fullResyncRef.current();
        await handlePassengerDropoff(passengerId, true, crypto.randomUUID()); return;
      } else { toast({ variant: "destructive", title: data.message || "Ошибка" }); }
    } catch (e: any) {
      if (e?.name === "AbortError") {}
      else if (!navigator.onLine) {
        enqueueAction({ type: "dropoff", endpoint: `${BASE_URL}/api/drivers/passenger/${passengerId}/dropoff`, method: "POST",
          headers: { ...refs.headersRef.current, "X-Action-Id": aid }, passengerId, rideId: refs.activeRideRef.current?.id, localLabel: "Высадить пассажира" });
        setters.setActivePassengers(prev => prev.map(p => p.id === passengerId ? { ...p, status: "dropped_off" } : p));
        toast({ title: "Сохранено офлайн" });
      } else { toast({ variant: "destructive", title: "Ошибка сети" }); }
    } finally {
      refs.isProcessingRef.current = false; refs.pendingResyncRef.current = false; setPassengerActionLoading(null);
      if (refs.routeRebuildTimer.current) clearTimeout(refs.routeRebuildTimer.current);
      if (navigator.onLine) refs.routeRebuildTimer.current = setTimeout(() => refs.fullResyncRef.current(), 300);
    }
  };

  const handleBatchPickup = async (ids: number[]) => {
    for (const id of ids) {
      if (refs.isProcessingRef.current) await new Promise<void>(r => { const iv = setInterval(() => { if (!refs.isProcessingRef.current) { clearInterval(iv); r(); } }, 100); });
      await handlePassengerPickup(id);
    }
  };

  const handleBatchDropoff = async (ids: number[]) => {
    for (const id of ids) {
      if (refs.isProcessingRef.current) await new Promise<void>(r => { const iv = setInterval(() => { if (!refs.isProcessingRef.current) { clearInterval(iv); r(); } }, 100); });
      await handlePassengerDropoff(id);
    }
  };

  const handleManualClient = async (seatNumber: number, gender: string, phone: string) => {
    const ride = refs.activeRideRef.current;
    if (!token || !ride || clientActionLoading) return;
    setClientActionLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/manual-client`, {
        method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ orderId: ride.id, seatNumber, gender, phone: phone || undefined }),
      });
      const data = await res.json();
      if (res.ok) { toast({ title: data.message || "Пассажир добавлен" }); await loadActiveRide(); }
      else { toast({ variant: "destructive", title: data.message || "Ошибка" }); }
    } catch { toast({ variant: "destructive", title: "Ошибка сети" }); }
    finally { setClientActionLoading(false); }
  };

  const handleGoOnline = async () => {
    try {
      const res = await fetch(`${BASE_URL}/api/drivers/status`, {
        method: "PATCH", headers: refs.headersRef.current, body: JSON.stringify({ status: "online" }),
      });
      if (res.ok) { toast({ title: "Вы на линии!" }); refreshUser(); }
      else { const err = await res.json().catch(() => ({})); toast({ variant: "destructive", title: err.message || "Ошибка" }); }
    } catch { toast({ variant: "destructive", title: "Ошибка сети" }); }
  };

  const handleCompletionClose = () => {
    setters.setCompletedRide(null);
    setters.setScreen(refs.isOnlineRef.current ? "route_select" : "idle");
    loadActiveRide();
  };

  return {
    actionLoading, passengerActionLoading, isCompleting, clientActionLoading,
    marketListings, buyingId, cities, availableRoutes, setCities, setAvailableRoutes,
    connection, isCompletingRef,
    loadActiveRide, loadMarketListings, handleBuyListing,
    handleCreateRide, handleStartRide, handleComplete, handleCancel,
    handlePassengerPickup, handlePassengerDropoff,
    handleBatchPickup, handleBatchDropoff,
    handleManualClient, handleGoOnline, handleCompletionClose,
  };
}
